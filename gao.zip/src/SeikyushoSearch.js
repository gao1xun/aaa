import React, { Component } from "react";


export default class SeikyushoSearch extends Component {
    constructor (props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                <MisocoHeader />
            </div>
        )
    }
}  

