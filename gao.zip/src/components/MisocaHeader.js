import React from 'react';
import MisocaTop from './MisocaTop';
import MisocaMenu from './MisocaMenu'

export default function MisocaHeader() {
  return (
    <div>
          <MisocaTop />

          <MisocaMenu />

      </div>
  );
}
